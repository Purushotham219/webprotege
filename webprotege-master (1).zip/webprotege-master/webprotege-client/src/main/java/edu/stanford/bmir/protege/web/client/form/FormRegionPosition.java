package edu.stanford.bmir.protege.web.client.form;

/**
 * Matthew Horridge
 * Stanford Center for Biomedical Informatics Research
 * 2020-04-23
 */
public enum FormRegionPosition {

    TOP_LEVEL,
    NESTED
}
