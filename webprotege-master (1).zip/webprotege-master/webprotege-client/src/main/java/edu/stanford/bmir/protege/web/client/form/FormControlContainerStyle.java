package edu.stanford.bmir.protege.web.client.form;

import com.google.gwt.resources.client.CssResource;

public interface FormControlContainerStyle extends CssResource {

    String main();

    String container();

    String deleteRowButton();

    String disabled();
}
