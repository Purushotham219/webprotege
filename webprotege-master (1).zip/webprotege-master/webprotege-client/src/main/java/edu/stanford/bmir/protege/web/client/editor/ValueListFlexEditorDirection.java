package edu.stanford.bmir.protege.web.client.editor;

/**
 * Matthew Horridge
 * Stanford Center for Biomedical Informatics Research
 * 10/04/16
 */
public enum ValueListFlexEditorDirection {

    ROW,

    COLUMN
}
