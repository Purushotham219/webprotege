package edu.stanford.bmir.protege.web.client;

public interface HasReadOnly {

    void setReadOnly(boolean readOnly);

    boolean isReadOnly();
}
