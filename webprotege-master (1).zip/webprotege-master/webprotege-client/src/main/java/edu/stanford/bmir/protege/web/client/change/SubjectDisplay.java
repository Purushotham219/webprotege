package edu.stanford.bmir.protege.web.client.change;

/**
 * Matthew Horridge
 * Stanford Center for Biomedical Informatics Research
 * 27/02/15
 */
public enum SubjectDisplay {

    DISPLAY_SUBJECT,

    DO_NOT_DISPLAY_SUBJECT
}
