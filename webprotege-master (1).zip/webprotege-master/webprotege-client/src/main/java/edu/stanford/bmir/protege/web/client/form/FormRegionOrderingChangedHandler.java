package edu.stanford.bmir.protege.web.client.form;

public interface FormRegionOrderingChangedHandler {

    void handleFormRegionOrderingChanged();
}
