package edu.stanford.bmir.protege.web.client.form;

/**
 * Matthew Horridge
 * Stanford Center for Biomedical Informatics Research
 * 2020-06-19
 */
public class FormRegionFilterChangedEvent {
}
